﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PinsameGUI.Models
{
    public abstract class Item
    {
    }
}
