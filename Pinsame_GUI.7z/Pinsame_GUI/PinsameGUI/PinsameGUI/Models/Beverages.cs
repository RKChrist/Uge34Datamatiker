﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PinsameGUI.Models
{
    public class Beverages : Item
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
    }
}
